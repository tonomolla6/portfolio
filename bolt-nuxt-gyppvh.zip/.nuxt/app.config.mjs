
import { defuFn } from '/home/projects/bolt-nuxt-z6qmpz/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
